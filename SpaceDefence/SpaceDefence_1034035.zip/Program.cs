﻿using var game = new SpaceDefence.SpaceDefence();
game.Run();
